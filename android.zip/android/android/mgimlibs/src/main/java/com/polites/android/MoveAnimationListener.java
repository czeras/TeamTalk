package com.polites.android;

public interface MoveAnimationListener {

	public void onMove(float x, float y);

}
