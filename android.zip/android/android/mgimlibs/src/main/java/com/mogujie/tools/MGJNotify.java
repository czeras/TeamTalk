package com.mogujie.tools;


public class MGJNotify {

}