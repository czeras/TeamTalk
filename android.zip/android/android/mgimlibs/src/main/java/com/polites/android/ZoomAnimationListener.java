package com.polites.android;

public interface ZoomAnimationListener {
	public void onZoom(float scale, float x, float y);

	public void onComplete();
}
