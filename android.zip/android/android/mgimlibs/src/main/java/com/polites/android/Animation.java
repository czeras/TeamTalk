package com.polites.android;

public interface Animation {
	public boolean update(GestureImageView view, long time);

}
