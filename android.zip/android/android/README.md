android TT编译环境要求
* IDE使用Android-studio 
* java 1.7
* gradle 2.2.1
