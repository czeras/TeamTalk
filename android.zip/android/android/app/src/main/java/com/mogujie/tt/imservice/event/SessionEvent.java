package com.mogujie.tt.imservice.event;

/**
 * @author : yingmu on 14-12-30.
 * @email : yingmu@mogujie.com.
 */
public enum  SessionEvent {

   RECENT_SESSION_LIST_SUCCESS,
   RECENT_SESSION_LIST_FAILURE,

   //回话人列表更新
   RECENT_SESSION_LIST_UPDATE,

   SET_SESSION_TOP

}
