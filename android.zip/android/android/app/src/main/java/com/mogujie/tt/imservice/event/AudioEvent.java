package com.mogujie.tt.imservice.event;

/**
 * @author : yingmu on 15-1-20.
 * @email : yingmu@mogujie.com.
 */
public enum AudioEvent {
    AUDIO_STOP_PLAY
}
