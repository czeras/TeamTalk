package com.mogujie.tt.imservice.event;

/**
 * @author : yingmu on 15-1-7.
 * @email : yingmu@mogujie.com.
 */
public enum ImageMsgEvent {
    HANDLER_IMAGE_UPLOAD_FAILD,
    HANDLER_IMAGE_UPLOAD_SUCESS;
}
