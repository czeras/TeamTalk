package com.mogujie.tt.ui.base;

import androidx.fragment.app.FragmentActivity;

public abstract class TTBaseFragmentActivity extends FragmentActivity {
   
}
