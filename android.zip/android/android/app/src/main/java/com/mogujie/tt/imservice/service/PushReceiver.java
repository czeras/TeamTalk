//package com.mogujie.tt.imv2.service;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.os.Bundle;
//
////import com.mogujie.sdk.PushConsts;
////import com.mogujie.sdk.PushManager;
//
//public class PushReceiver extends BroadcastReceiver {
//    public PushReceiver() {
//    }
//
//    @Override
//    public void onReceive(Context context, Intent intent) {
//
////        String action  = intent.getAction();
////        Bundle bundle = intent.getBundleExtra(PushConsts.MESSAGE_BUNDLE);
////        int message_id = bundle.getInt(PushConsts.MESSAGE_ID);
////        String message_data = new String(bundle.getByteArray(PushConsts.MESSAGE_DATA));
////        String app_id = new String(bundle.getByteArray(PushConsts.APP_ID));
////        PushManager.getInstance().readMessage(message_id);
//
//    }
//}
