
package com.mogujie.tt.ui.adapter.album;

import java.util.List;

/**
 * @Description 相册数据体
 * @author Nana
 * @date 2014-5-9
 */
public class ImageBucket {
    public int count = 0;
    public String bucketName;
    public List<ImageItem> imageList;

}
