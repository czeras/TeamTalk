//
//  DDAvatarImageView.h
//  IMBaseSDK
//
//  Created by 独嘉 on 14/11/17.
//  Copyright (c) 2014年 mogujie. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTTAvatarImageView : UIImageView
- (void)setAvatar:(NSString*)avatar group:(BOOL)group;
@end
