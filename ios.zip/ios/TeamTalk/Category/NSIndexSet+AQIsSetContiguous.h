//
//  NSIndexSet+AQIsSetContiguous.h
//  AQGridView
//
//  Created by Jim Dovey on 10-04-17.
//  Copyright 2010 Kobo Inc. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NSIndexSet (AQIsSetContiguous)
- (BOOL) aq_isSetContiguous;
@end
