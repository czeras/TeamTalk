//
//  UILabel+VerticalAlign.h
//  TeamTalk
//
//  Created by scorpio on 15/6/30.
//  Copyright (c) 2015年 MoguIM. All rights reserved.
//

#import <UIKit/UIKit.h>
@interface UILabel (VerticalAlign)
- (void)alignTop;
- (void)alignBottom;
@end
