//
//  DDFixedGroupAPI.h
//  Duoduo
//
//  Created by 独嘉 on 14-5-6.
//  Copyright (c) 2015年 MoguIM All rights reserved.
//

#import "DDSuperAPI.h"

@interface DDFixedGroupAPI : DDSuperAPI

@end
