//
//  DMTTDepartment.h
//  IOSDuoduo
//
//  Created by Michael Scofield on 2014-08-05.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface DMTTDepartmentAPI : DDSuperAPI

@end
