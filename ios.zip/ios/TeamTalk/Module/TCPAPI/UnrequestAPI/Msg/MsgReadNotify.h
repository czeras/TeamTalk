//
//  MsgReadNotify.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-12-19.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDUnrequestSuperAPI.h"

@interface MsgReadNotify : DDUnrequestSuperAPI<DDAPIUnrequestScheduleProtocol>

@end
