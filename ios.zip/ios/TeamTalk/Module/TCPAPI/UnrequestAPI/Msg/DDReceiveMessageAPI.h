//
//  DDReceiveMessageAPI.h
//  IOSDuoduo
//
//  Created by 独嘉 on 14-6-5.
//  Copyright (c) 2014年 dujia. All rights reserved.
//

#import "DDUnrequestSuperAPI.h"

@interface DDReceiveMessageAPI : DDUnrequestSuperAPI<DDAPIUnrequestScheduleProtocol>

@end
