//
//  SendPushTokenAPI.h
//  TeamTalk
//
//  Created by Michael Scofield on 2014-09-17.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import "DDSuperAPI.h"

@interface SendPushTokenAPI : DDSuperAPI

@end
