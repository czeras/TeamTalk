//
//  MTTURLProtocal.h
//  TeamTalk

#import <Foundation/Foundation.h>

@interface MTTURLProtocal : NSURLProtocol

@end
