//
//  MTTPCLoginViewController.h
//  TeamTalk
//
//  Created by scorpio on 15/7/17.
//  Copyright (c) 2015年 MoguIM. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTTPullScrollViewController.h"

@interface MTTPCLoginViewController : MTTPullScrollViewController

@end
