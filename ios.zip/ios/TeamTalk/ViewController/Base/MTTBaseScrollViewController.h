//
//  MTTBaseScrollViewController.h
//  TeamTalk
//
//  Created by 宪法 on 15/6/19.
//  Copyright (c) 2015年 MoguIM. All rights reserved.
//

#import "MTTBaseViewController.h"


@interface MTTBaseScrollViewController : MTTBaseViewController

@property (nonatomic,assign) UIScrollView *scrollView;

@end
