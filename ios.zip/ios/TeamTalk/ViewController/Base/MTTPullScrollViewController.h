//
//  MTTPullScrollViewController.h
//  TeamTalk
//
//  Created by 宪法 on 15/6/19.
//  Copyright (c) 2015年 MoguIM. All rights reserved.
//

#import "MTTBaseScrollViewController.h"

@interface MTTPullScrollViewController : MTTBaseScrollViewController

@end
