//
//  MTTSearchShowMore.h
//  TeamTalk
//
//  Created by scorpio on 15/7/7.
//  Copyright (c) 2015年 MoguIM. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MTTSearchShowMoreCell : UITableViewCell

@end
