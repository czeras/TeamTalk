//
//  MTTRootViewController.m
//  IOSDuoduo
//
//  Created by Michael Scofield on 2014-07-15.
//  Copyright (c) 2014 dujia. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ContactsViewController.h"
@interface MTTRootViewController : UITabBarController
@end
